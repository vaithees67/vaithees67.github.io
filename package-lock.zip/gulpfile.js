var gulp = require('gulp');
var runSequence = require('run-sequence');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');


/* Import gulp task packages as required
 ========================================================================== */

// Common
require('./gulp/tasks/fonts');
require('./gulp/tasks/html');
require('./gulp/tasks/images');
require('./gulp/tasks/lint');
require('./gulp/tasks/serve');
require('./gulp/tasks/styles');
require('./gulp/tasks/scripts');
require('./gulp/tasks/utility');


var $ = gulpLoadPlugins();
var reload = browserSync.reload;
var stream = browserSync.stream;


// Build production files, the default task
gulp.task('build', ['clean'], function (done) {
  runSequence(
    'styles','component_styles',
    [
      'html',
      'component_pages',
      'scripts',
      'component_scripts',
      'images',
      'fonts',
      'copy'
    ],
    'createIndexLink',
    done,
  );
});

gulp.task('default', ['build']);
