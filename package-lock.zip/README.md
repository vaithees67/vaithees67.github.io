# UI Solution Approach for Development / Platform Migration

## How it is Different

* This approach is applicable for any UI development & Platform Migration (eCommerce, CMS)
*	This approach would be the base for building any Boiler Plate, Component library which can be build using the UI Tech stack (ReactJS, Angular, Ember..)
*	This approach enforces the developer to follow the design and coding principles strictly

## Why we should use?

*	Developer can concentrate on pure development rather than initial setup and configurations. Which makes developers life easier. 
*	Enforces the coding standards and best practices through Linting.
*	Removes the inconsistencies of the libraries and the frameworks.
*	Provides appropriate folder structure with UI frameworks.

## Design and Coding Principles

*	Should identify the templates and common components across pages at the initial stage.
*	Follow the BEM standards for naming the components
*	Separate the HTMLs in to a componentized pattern (e.g. “accordion.html”, “carousel.html”)
*	Advisable to maintain component specific CSS and handle nested classes to control the UI in a better way
*	Identify the inline JavaScript from each of the component and create a custom JS file (e.g. component.js) to include in all the pages
*	For each component, there would be a separate HTML, CSS and Javascript files. 
*	Avoid in-line styles and in-line JavaScript in the HTML code
*	Develop the component considering the mobile first approach
*	SVG Masking for Images:  JPEG images should be used for SVG Notch/Curve Images
*	Minification: All the JS and CSS files should be minified 
*	GZIP components: Ensure the web server compiled with GZIP so that the assets (JS, CSS) can be further optimized while loading in the client browser
*	Adaptive Images: Create specific adaptive rendition size of images and rendering as per predefined component sizes

## Tech Stack 
*	Bootstrap4, Webpack, Babel, SASS, HTML5, CSS3, NodeJS, Handlebars

## Pre-requisites

* Node >= 8
* NPM >= 5

## Installation

* `npm i`

See scripts section in `package.json` for convenient access to most commonly used tasks. These include:

* Full Build: `npm run build`
* Dev Env: `npm run start`
  * Live reloading on watched code changes.
  * [Browsersync]{https://www.browsersync.io/} integration for simultaneous multi-browser testing.
* SCSS & JS Lint (code formatting): `npm run lint`

## Branching Strategy

* Feature branch names should use the following Git Flow-esque format - `feature/{feature_name}`.
* All merge requests are merged using the "Fast-Forward Merge" method.
    https://docs.gitlab.com/ee/user/project/merge_requests/fast_forward_merge.html
* Feature branches should be rebased on to `develop` before submitting a merge request. It should be possible for Gitlab to fast-forward a developer's feature branch on to `develop` (see previous bullet).
* Developers should squash all feature branch commits in to a single commit before submitting a merge request.

## Tools

### Gulp

* Gulp is used to transpiling the Handlebars and SCSS files to HTML and CSS.
* All gulp tasks are imported seqentially in `gulpfile.js` and it is in the root folder.
* You can see individual task js files for html, styles, scripts, images, fonts and lint under `gulp/task` folder.
* You can also customize the tasks based on your project needs.

### Webpack

* Webpack transpiles ECMAScript to ES5(ES2015) and also bundling the js files.
* Uglifiy pluign is included for js minification.
* Used two webpack configuration js file for whole and split bundling of js files. Configuration files are under `gulp` folder `webpack_components.config.js` and `webpack.config.js`.

### Lints

1. CSS linting is executed through stylelint which is governed by rules available in .stylelintrc.json.
2. JS linting is achieved through eslint which is configured through instructions at .eslintrc.json.

### Templating

* Handlebars (https://handlebarsjs.com/) templating engine.
* Template inheritance and composition capability.
* Components / patterns encapsulated in Handlebar partials with explicit APIs.
* Fixtures data is injected in to templating engine based on page name.

### CSS

* [SCSS](http://sass-lang.com/).
* BEM naming conventions.
* Idiomatic CSS comment style ( [https://github.com/necolas/idiomatic-css#3-comments](https://github.com/necolas/idiomatic-css#3-comments) ).
* [Eyeglass](https://github.com/sass-eyeglass/eyeglass) integration for NPM style SCSS module resolution.
* Media Query support from [@include-media](https://include-media.com/)
* Third party support from [Foundation](http://foundation.zurb.com/).
* Additional [Quantity queries](https://github.com/danielguillan/quantity-queries) support - see this [A List Apart article](https://alistapart.com/article/quantity-queries-for-css) for more information.

## Anatomy of SCSS rule

* Scopes should not be used as top-level containers, they should only be used for additional styling within subelements of other components

```sass
.class {
  // 1. Mixins
  @include bravo-typeset(copy);

  // 2. Mobile-first declarations
  padding: 8px;
  color: red;

  // 3. Responsive declarations in ascending breakpoint order
  @include for-tablet-up {
    padding: 12px;
  }
  
  @include for-desktop-up {
    padding: 24px;
  }

  // 4. Modifier-driven declarations
  @at-root {
    .class--inverse & {
      color: blue;
    }
  }

  // 5. Concatenated selector expressions 
  //    (not applicable to BEM Block rules)
  &-subelement {
    font-size: 3rem;
  }
}
```

### JavaScript

* ES2015 / ES6
* Babel transpiler

### Browser support

Configure browserslist property in `package.json` to set support level with conforming libraries. 

* Vendor prefixing: Provided by Autoprefixer, a module built on top of PostCSS.

## Folder Structure:
    __src
      ├───components_pages
      ├───fonts
      ├───media
      │   ├───icons
      │   ├───images
      │   ├───sprites
      │   └───videos
      ├───partials
      │   ├───components
      │   └───layouts
      ├───scripts
      │   ├───components
      │   └───vendor
      └───styles
          ├───cms
          ├───components
          ├───components-mixin
          ├───core
          ├───utility
          └───vendor
<ul>
  <li><p><strong>index.hbs</strong> Index template file, which will create the link of the components and pages automatically</p></li>
  <li><p><strong>about.hbs</strong> About template file, This is the example page with various assembled components to see the whole view of the page and also used for demo purpose. Like this you can create pages with developed components eg: about.hbs, contact.hbs etc.</p></li>

  <li><p><strong>src/component_pages</strong></p><p><strong>component_pages</strong> folder will have components demo page with variations. Page name should be unique with respective component's name.</p></li>

  <li><p><strong>src/fonts</strong></p><p><strong>fonts</strong> will have fonts related files.</p></li>

  <li><p><strong>src/media</strong></p><p><strong>media</strong> will have icons, images, sprites and videos related files. You can keep the media files in the respective folder under media.</p></li>

  <li><p><strong>src/partials</strong></p><p><strong>partials</strong> will have components and layouts handlebar files.</p>
    <ul>
      <li><p><strong>src/partials/components</strong></p><p><strong>components</strong> will have components handlebar files. Any new component development, the html snippet goes in new handlebar file with component name. eg accordion.hbs,header.hbs, footer.hbs</p></li>
      <li><p>src/partials/layouts</p><p><strong>layouts</strong> will have page templates files. You can create templates based on your requirements and needs.</p></li>
    </ul>
  </li>

  <li><p><strong>src/scripts</strong></p><p><strong>scripts</strong> will have componnents and vendor js files.</p>
    <ul>
      <li><p><strong>src/scripts/components</strong></p><p><strong>components</strong> will have components js files. Any new component development have js functionality will goes with new js file with respective component name. eg accordion.js, header.js</p></li>
      <li><p><strong>src/partials/vendor</strong></p><p><strong>layouts</strong> will have all the external js library files. You can keep all the external jquery libaray files under this folder.</p></li>
    </ul>
  </li>

  <li><p><strong>src/styles</strong></p><p><strong>styles</strong> will have cms, components, components-mixin, core, utility and vendor SCSS files.</p>
    <ul>
      <li><p><strong>src/styles/cms</strong></p><p><strong>cms</strong> contains scss file ie: cms-overrider.scss. You can add the styles here to overriding Content Management System default styles if needed eg. AEM,Site Core.</p></li>
      <li><p><strong>src/styles/components</strong></p><p><strong>components</strong> contains components sccs files to generate individual component css files. eg accordion.scss, header.scss. Any new component development, create a scss file under this folder and import all the scss dependency for this component and import component mixin created newly in same name under components-mixin folder.</p></li>
      <li><p><strong>src/styles/components-mixin</strong></p><p><strong>components-mixin</strong> will have components scss files. Any new component development styles will goes with new scss file with respective component name. eg _accordion.scss, _header.scss. Component styles are added in newly created mixin in same name of the component.</p></li>
      <li><p><strong>src/styles/core</strong></p><p><strong>core</strong> contains core scss files.</p>
          <p><strong>_accessibility.scss</strong> To add accessibility related stlyes.</p>
          <p><strong>_branding.scss</strong> To add branding variables for color schemes, fonts, branding mixin for global use.</p>
          <p><strong>_fonts.scss</strong> To add font mixin to import fonts for the application.</p>
          <p><strong>_functions.scss</strong> To add common mixin funtion for global use.</p>
          <p><strong>_reset.scss</strong> To add the reset css for browser</p>
          <p><strong>_settings.scss</strong> To add the configuration setting variables like breakpoints, browser name etc.</p>
      </li>
      <li><p><strong>src/styles/utility</strong></p><p><strong>utility</strong> contains core scss files.</p>
          <p><strong>_breakpoints.scss</strong> To add breakpoints mixin funtions. Already mixins are availble you can reuse or customized it based on your needs.</p>
          <p><strong>_helper.scss</strong> To add helper classes css styles for global use.</p>
          <p><strong>_spacing.scss</strong> To add spacing classes css styles for global use.</p>
          <p><strong>_functions.scss</strong> To add common mixin funtion for global use.</p>
          <p><strong>_typesetting.scss</strong> To add the font configuration setting like font size and font mixin.</p>
      </li>
      <li><p><strong>src/styles/vendor</strong></p><p><strong>vendor</strong> will have all the external plugin or library related css files. You can keep all the external css libaray files under this folder.</p></li>
      <li><p><strong>app_default.scss</strong> will be in the root level styles folder.To generate whole css in sinlge file, import all the scss dedendecies and all the component mixins here.</p></li>
      <li><p><strong>global.scss</strong> will be in the root level styles folder. To split up generation of css, import only the global dependency scss here and rest of the componets mixins in their respective styles/components folder.</li>
      <li><p>If you need to generate any separate css file, you can create a scss file under this folder and import the scss eg. app_critical.scss</p>
    </ul>
  </li>
</ul>

## Dist folder Structure:

  Run the `npm run build` command to generate the dist folder in below structure:

    __dist
      ├───components_pages
      │   ├───accordion
      │   │   ├───accordion.css
      │   │   ├───accordion.html
      │   │   └───accordion.js          
      │   ├───button
      │   ├───card
      │   ├───footer
      │   ├───page-header 
      │   └───header
      ├───fonts
      ├───media
      │   ├───icons
      │   ├───images
      │   ├───sprites
      │   └───videos
      ├───scripts
      │   ├───app.js
      │   └───vendor.js
      ├───styles
      │   ├───app_critical.css
      │   ├───app_default.css
      │   ├───cms-overrider.css
      │   └───global.css
      ├───index.html
      └───about.html
