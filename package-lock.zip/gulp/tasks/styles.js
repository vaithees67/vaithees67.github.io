var gulp = require('gulp');
var eyeglass = require('eyeglass');
var config = require('../config');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');
var es = require('event-stream');
var crypto = require('crypto');
var rename = require('gulp-rename');

// PostCSS processors
var autoprefixer = require('autoprefixer');
var cssnano = require('cssnano');

var $ = gulpLoadPlugins();

var sassOptions = {
  precision: 10,
  eyeglass: {},
};


// load package.json
var packageJson = require('../../package.json');


function headerTransforms(name) {
  if (name) {
    name = ' (' + name + ')';
  }

  function transform(file, cb) {
    var string = String(file.contents);

    // remove existing charset declarations, as it needs to be the very first thing in the CSS file
    string = string.replace(
      new RegExp('@charset "UTF-8";', 'g'),
      '',
    );

    // write charset declaration and header comment
    var hash = crypto.createHash('md5').update(string).digest('hex');
    string = '@charset "UTF-8";\n/**\n* CTS DEP$' + (name || '') + ' v' + packageJson.version + ' (' + (new Date()).toUTCString().replace('GMT', 'UTC') + ')\n* ' + hash + '\n*/\n' + string;

    // write changed output
    file.contents = new Buffer(
      string
    );

    // run callback to complete pipe
    cb(null, file);
  }

  return es.map(transform);
}


// Compile and automatically prefix stylesheets
gulp.task('styles', function () {
  return gulp.src([
    'src/styles/cms/*.scss','src/styles/*.scss'
  ])
    .pipe($.newer('.tmp/styles'))
    .pipe($.sass(
      eyeglass(sassOptions)
    ).on('error', $.sass.logError))
    .pipe($.postcss([
      autoprefixer(),
    ]))
    .pipe(gulp.dest('.tmp/styles'))
    .pipe($.postcss([
      cssnano({
        autoprefixer: false,
      }),
    ]))
    .pipe(headerTransforms())
    .pipe(gulp.dest(config.paths.dist + 'styles'))
    .pipe($.size({ title: 'styles' }))
    .pipe(browserSync.stream());
});

gulp.task('component_styles', function () {
  return gulp.src([
    'src/styles/components/*.scss',
  ])
    .pipe($.newer('.tmp/styles'))
    .pipe($.sass(
      eyeglass(sassOptions)
    ).on('error', $.sass.logError))
    .pipe($.postcss([
      autoprefixer(),
    ]))
    .pipe(gulp.dest('.tmp/styles'))
    .pipe($.postcss([
      cssnano({
        autoprefixer: false,
      }),
    ]))
    .pipe(rename(function (path) {
      path.dirname += "/" + path.basename;
      }))
    .pipe(gulp.dest('./dist/component_pages'))
    .pipe($.size({ title: 'component_styles' }))
    .pipe(browserSync.stream());
});
