var gulp = require('gulp');
var config = require('../config');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');
var hbsAll = require('gulp-handlebars-all');
var handlebars = require('gulp-compile-handlebars');
var rename = require('gulp-rename');

var $ = gulpLoadPlugins();
var reload = browserSync.reload;
var inject = require('gulp-inject');


// load package.json
var packageJson = require('../../package.json');


gulp.task('component_pages', () => {
  return gulp.src('./src/component_pages/*.hbs')
    .pipe(handlebars({}, {
    ignorePartials: true,
    batch: ['./src/partials']
    }))
    .pipe(rename(function (path) {
    path.dirname += "/" + path.basename;
    path.extname = ".html";
    }))
    .pipe(gulp.dest('./dist/component_pages'))
    .on('end', reload);
});

gulp.task('html', () => {
  return gulp.src('./src/*.hbs')
    .pipe(handlebars({}, {
      ignorePartials: true,
      batch: ['./src/partials']
    }))
    .pipe(rename({
      extname: '.html'
    }))
    .pipe(gulp.dest('./dist'))
    .on('end', reload);
});


gulp.task('createIndexLink', () => {
  gulp.src('./dist/index.html')
    .pipe(inject(
      gulp.src(['./dist/component_pages/**/*.html'], { read: false }), {
        transform: function (filepath) {
          if (filepath.slice(-5) === '.html') {
            return '<li><a href="' + filepath.slice(5) + '">' + filepath.split("/").pop().split(".").slice(0, 1) + '</a></li>';
          }
          // Use the default transform as fallback:
          arguments[0] = filepath + '?v=' + pjson.version;
          return inject.transform.apply(inject.transform, arguments);
        }
      }
    ))
    .pipe(gulp.dest('./dist'))
    .on('end', reload);
});
