var gulp = require('gulp');
var runSequence = require('run-sequence');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');

var $ = gulpLoadPlugins();
var reload = browserSync.reload;

// Lint JS
gulp.task('lint.js', function () {
  return gulp.src('src/scripts/components/*.js')
    .pipe($.eslint())
    .pipe($.eslint.format())
    .pipe($.if(!browserSync.active, $.eslint.failAfterError()));
});

// Lint SCSS
gulp.task('lint.css', function () {
  return gulp.src('src/styles/**/*.{scss,css}')
    .pipe($.stylelint({
      reporters: [
        { formatter: 'string', console: true },
      ],
    }));
});

// Lint and fix SCSS
gulp.task('lint.fix.css', function () {
  return gulp
    .src('src/styles/**/*.{scss,css}')
    .pipe($.stylelint({
      fix: true,
    }))
    .pipe(gulp.dest(function (file) {
      return file.base;
    }));
});

// Lint JS and (S)CSS
gulp.task('lint', ['build'], function (done) {
  runSequence(
    'lint.js',
    'lint.css',
    done,
  );
});

// Lint JS and (S)CSS (faster, as expects that the build has already been done)
gulp.task('fastlint', function (done) {
  runSequence(
    'lint.js',
    'lint.css',
    done,
  );
});
