var gulp = require('gulp');
var config = require('../config');
var portfinder = require('portfinder');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');


var $ = gulpLoadPlugins();
var reload = browserSync.reload;


// Watch files for changes & reload
gulp.task('serve', ['build'], function () {
  portfinder.getPort(
    {
      port: 3000,
      stopPort: 3100
    },
    function (err, openPort) {
      browserSync({
        port: openPort,
        ui: {
          port: (openPort + 1),
        },
        notify: false,
        logPrefix: 'BrowserSync',
        server: ['dist', 'src'],
      });
    }
  );

  var runSequence = require('run-sequence');
  gulp.watch(['src/**/*.{html,hbs}'],
    function() {
      runSequence("html", "createIndexLink")
  });
  gulp.watch(['src/**/*.{html,hbs}'], ['component_pages']);
  gulp.watch(['src/styles/**/*.{scss,css}'], ['styles','component_styles']);
  gulp.watch(['src/scripts/**/*.js'], ['scripts','component_scripts']);
  gulp.watch(['src/images/**/*'], reload);
});


// Build and serve the output from the dist build
gulp.task('serve:dist', ['build'], function () {
  browserSync({
    notify: false,
    logPrefix: 'BrowserSync',
    server: config.paths.dist,
    baseDir: config.paths.dist,
  });
});
