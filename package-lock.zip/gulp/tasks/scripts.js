var gulp = require('gulp');
var config = require('../config');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');
var webpack = require('webpack-stream');
var rename = require('gulp-rename');

var webpackConfig = require('../webpack.config');
var webpackComponentsConfig = require('../webpack_components.config');

var $ = gulpLoadPlugins();
var reload = browserSync.reload;


// Compile / transpile and minify JavaScript
gulp.task('scripts', function () {
  return gulp.src([
    'src/scripts/**/*.js',
  ])
    .pipe(
      webpack(webpackConfig).on('error', (err) => {
        console.log('WEBPACK ERROR', err);
      })
    )
    .pipe(gulp.dest(config.paths.dist + 'scripts'))
    .pipe(gulp.dest('.tmp/scripts'))
    .on('end', reload);
});

gulp.task('component_scripts', function () {
  return gulp.src([
    'src/scripts/components/*.js',
  ])
    .pipe(
      webpack(webpackComponentsConfig).on('error', (err) => {
        console.log('WEBPACK ERROR', err);
      })
    )
    .pipe(rename(function (path) {
      path.dirname += "/" + path.basename;
      }))
    .pipe(gulp.dest('./dist/component_pages'))
    .pipe(gulp.dest('.tmp/scripts'))
    .on('end', reload);
});
