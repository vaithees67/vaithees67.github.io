var gulp = require('gulp');
var gulpLoadPlugins = require('gulp-load-plugins');

// plato
gulp.task('quality.plato', function () {

});

// jsdoc
gulp.task('quality.jsdoc', function () {

});

// pagespeed
gulp.task('quality.pagespeed', function () {

});

gulp.task('quality', ['build'], (cb) => {
  runSequence(
    [
      'quality.plato',
      'quality.jsdoc',
      'quality.pagespeed',
    ],
    cb);
});
