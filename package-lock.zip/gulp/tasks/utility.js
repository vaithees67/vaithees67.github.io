var gulp = require('gulp');
var config = require('../config');
var browserSync = require('browser-sync');
var gulpLoadPlugins = require('gulp-load-plugins');
var del = require('del');

var $ = gulpLoadPlugins();
var reload = browserSync.reload;


// Clean target directory
gulp.task('clean', () => del([
  config.paths.tmp,
  config.paths.dist + '{images,fonts,media,styles,scripts,component_pages}',
  config.paths.dist + '*.html',
  config.paths.dist + '*.zip',
], {dot: true, force: true}));


// Copy all files at the root level (src)
gulp.task('copy', function () {
  return gulp.src([
    'src/{images,fonts,media}/**/*',
  ], {
    dot: true
  }).pipe(gulp.dest(config.paths.dist))
    .pipe($.size({title: 'copy'}));
});
