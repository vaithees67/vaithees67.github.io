var gulp = require('gulp');
var config = require('../config');
var gulpLoadPlugins = require('gulp-load-plugins');

var $ = gulpLoadPlugins();


// Copy web fonts to dist
gulp.task('fonts', function () {
  return gulp.src(['src/fonts/**/*.{eot,svg,ttf,woff,woff2}'])
    .pipe(gulp.dest(config.paths.dist + 'fonts'))
    .pipe($.size({title: 'fonts'}));
});
