const path = require('path');
const webpack = require('webpack');

const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

module.exports = {

  entry: {
    app: [
      './src/scripts/vendor/app.js',
      './src/scripts/components/accordion.js',
    ],
    vendor: [
      './src/scripts/vendor/app.js',
    ]
  },

  mode: 'production',

  output: {
    path: path.join(__dirname, 'dist', 'js'),
    filename: '[name].js',
  },

  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['es2015'],
          },
        },
      },
    ],
  },

  optimization: {
    minimizer: [
      new UglifyJsPlugin({
        uglifyOptions: {
          compress: {
            warnings: false,
          },
          output: {
            comments: false,
          },
        },
      }),
    ],
  }

};
