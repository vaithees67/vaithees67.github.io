;(($, window, document) => {
  // onload
  $(() => {
    $('.collapse').collapse({
      toggle: true
    });
  });
})(jQuery, window, document);
